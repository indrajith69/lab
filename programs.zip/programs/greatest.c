#include<stdio.h>
void main()
{
	int a,b;
	printf("enter two number \n");
	scanf("%d%d",&a,&b);
	if (a>b)
	{
		printf("%d is the greatest \n",a);
	}
	else
	{
		printf("%d is the greatest \n",b);
	}
}

