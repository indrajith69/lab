#include<stdio.h>
void main()
{
	int number;
	printf("enter a number ");
	scanf("%d",&number);
	if (number<0)
	{
		printf("%d is negative \n",number);
	}
}
